//Auth User End Points
export { 
    createUser,
    loginUser,
    getToken,

} from './auth';

export {
    GetAllPatient,
 } 
from './afterAuth'