//export all endpoints
export { endPoints } from './url';

//export all headers
export { commonHeader } from './header';