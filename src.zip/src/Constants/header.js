// import AsyncStorage from '@react-native-community/async-storage';
// const token = AsyncStorage.getItem('token');
// const user_id =  AsyncStorage.getItem('user_id');

export const commonHeader =  {
    'Accept': '*/*',
    'Content-Type': 'application/json',   
    'x-api-key': 'leo@2020' ,    
  }

// export const commonHeader = {
//   'Accept': '*/*',
//   'Content-Type': 'application/json',   
//   'x-api-key': 'thelyfeapp@2020' ,
//   'user-id' : `${user_id}`,
//   'token' : `${token}`
// }
  